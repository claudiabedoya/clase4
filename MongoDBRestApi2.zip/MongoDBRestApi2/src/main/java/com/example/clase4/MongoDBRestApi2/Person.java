package com.example.clase4.MongoDBRestApi2;

import org.springframework.data.annotation.Id;

public class Person {
	
	@Id private String id;
	
	private String firtsName;
	private String lastName;
	
	public String getFirstName() {
		return firtsName;
	}
	
	public void setFirtsName (String firtsName) {
		this.firtsName= firtsName;
		
	}

	public String getlastName() {
		return lastName;
	}
	
	public void setlastName (String lastName) {
		this.lastName= lastName;
		
	}
}
