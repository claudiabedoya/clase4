package com.example.clase4.MongoDBRestApi2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbRestApi2Application {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbRestApi2Application.class, args);
	}

}
