package com.example.clase4.MongoDBRestApi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.clase4.MongoDBRestApi.model.Student;

public interface StudentRepository extends MongoRepository<Student, String>  {

}
