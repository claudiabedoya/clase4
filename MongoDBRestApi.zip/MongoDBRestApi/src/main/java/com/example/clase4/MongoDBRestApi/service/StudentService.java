package com.example.clase4.MongoDBRestApi.service;

import java.util.Optional;

import com.example.clase4.MongoDBRestApi.model.Student;

public interface StudentService {
	
	public Iterable<Student> findAll();

	public Student save(Student student);

	public Optional<Student> findByID(String id);

	public void removeStudent(String id);
	

}
